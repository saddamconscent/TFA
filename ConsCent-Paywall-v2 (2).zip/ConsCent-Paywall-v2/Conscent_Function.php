<?php
function contentIdExist($postArray) {
    $curl = curl_init();
    $postJsonData['clientContentId'] = (string)$postArray['ID'];
    $postJsonData['clientId'] = (string)CONSCENT_CLIENT_ID;
    curl_setopt_array($curl, array(CURLOPT_URL => CONSCENT_API_URL . "/api/v2/content/?clientContentId=" . $postJsonData['clientContentId'] . "&clientId=" . $postJsonData['clientId'], CURLOPT_RETURNTRANSFER => true, CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET",));
    $response = curl_exec($curl);
    $responseArray = json_decode($response);
    curl_close($curl);
    if ($responseArray->statusCode) {
        return false;
    } else {
        return true;
    }
}
/***/
function editContentOnConscent($postArray) {
    $curl = curl_init();
    $postJsonData['contentId'] = $contentId = (string)$postArray['ID'];
    $title = $postJsonData['title'] = (string)get_post_field('post_title');
    $postJsonData['price'] = (int)$postArray['conscent_price'];
    $postJsonData['duration'] = (int)(($postArray['conscent_duration'] == '' || $postArray['conscent_duration'] < CONSCENT_DEFAULT_STORY_DURATION) ? CONSCENT_DEFAULT_STORY_DURATION : $postArray['conscent_duration']);
    $authorId = $postJsonData['authorId'] = get_post_field('post_author', $postArray['ID']);
    $authorName = $postJsonData['authorName'] = get_the_author_meta('first_name', $postJsonData['authorId']);
    foreach (get_the_tags($contentId) as $tag) {
        $tags_list[] = $tag->name;
    }
    $tagslist = json_encode($tags_list);
    $category_detail = get_the_category($contentId); //$post->ID
    foreach ($category_detail as $cd) {
        $cat_name[] = $cd->cat_name;
    }
    $catname = json_encode($cat_name);
    $url = $postJsonData['url'] = get_permalink($postArray['ID']);
    $postJsonData = json_encode($postJsonData);
    $sections_names = wp_get_object_terms($postArray['ID'], 'sections', array("fields" => "names"));
    $sectionslist = json_encode($sections_names);
    $curl = curl_init();
    curl_setopt_array($curl, array(CURLOPT_URL => CONSCENT_API_URL . "/api/v2/content/" . $contentId, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "PATCH", CURLOPT_POSTFIELDS => '{

    "contentId" : $contentId,
    "title":$title,
	"authorName":$first_name,
	"authorId":$authorId,
	"url": $url,
    "categories": $catname,
	 "sections": $sectionslist,
    "tags": $tagslist

   }', CURLOPT_HTTPHEADER => array("Authorization: Basic " . base64_encode($apiKeySecret), "Content-Type: application/json"),));
    $response = curl_exec($curl);
    curl_close($curl);
    $response;
    $responseArray = json_decode($response);
    //print_r($responseArray);
    if ($responseArray->statusCode) {
        return false;
    } else {
        return true;
    }
}
/***/
function addContentOnConscent($postArray) {
    $curl = curl_init();
    //echo "<pre>";print_r($postArray);die;
    $contentId = $postJsonData['contentId'] = (string)$postArray['ID'];
    $title = $postJsonData['title'] = (string)get_post_field('post_title');
    $postJsonData['price'] = (int)$postArray['conscent_price'];
    $postJsonData['duration'] = (int)(($postArray['conscent_duration'] == '' || $postArray['conscent_duration'] < CONSCENT_DEFAULT_STORY_DURATION) ? CONSCENT_DEFAULT_STORY_DURATION : $postArray['conscent_duration']);
    $authorId = $postJsonData['authorId'] = get_post_field('post_author', $postArray['ID']); //get_the_author_meta('ID');
    $authorName = $postJsonData['authorName'] = get_the_author_meta('first_name', $postJsonData->authorId);
    foreach (get_the_tags($contentId) as $tag) {
        $tags_list[] = $tag->name;
    }
    $tagslist = json_encode($tags_list);
    $category_detail = get_the_category($contentId); //$post->ID
    foreach ($category_detail as $cd) {
        $cat_name[] = $cd->cat_name;
    }
    $catname = json_encode($cat_name);
    $sections_names = wp_get_object_terms($postArray['ID'], 'sections', array("fields" => "names"));
    $sectionslist = json_encode($sections_names);
    $postJsonData['url'] = get_permalink($postArray['ID']);
    $postJsonData = json_encode($postJsonData);
    $apiKeySecret = CONSCENT_API_KEY . ":" . CONSCENT_API_SECRET;
    $curl = curl_init();
    curl_setopt_array($curl, array(CURLOPT_URL => CONSCENT_API_URL . "/api/v2/content/", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => '{

    "contentId" : $contentId,
    "duration" : 30,
    "title" : $title,
    "price" : 1,
    "currency": "INR",
    "url": $url,
    "contentType": "STORY",
    "categories": $catname,
    "tags": $tagslist,
    "sections": $sectionslist,
    "authorId": $authorId,
	"authorName": $authorName
   }', CURLOPT_HTTPHEADER => array("Authorization: Basic " . base64_encode($apiKeySecret), "Content-Type: application/json"),));
    $response = curl_exec($curl);
    curl_close($curl);
     $response;
    $responseArray = json_decode($response);
    if ($responseArray->statusCode) {
        return false;
    } else {
        return true;
    }
}
?>