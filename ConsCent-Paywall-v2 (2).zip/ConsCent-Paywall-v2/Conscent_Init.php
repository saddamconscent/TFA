<?php
/*
 * Plugin Name: ConsCent Paywall V2
 * Description: ConsCent for WordPress! 
 * It is not just only plugin but it symbolizes the hope and enthusiasm of an entire media houses to not provide content for free. Content is precious.
 * Author: ConsCent Developers
 * Author URI: https://conscent.in
 * Version: 2.0
 *  
 */
ini_set('display_errors', '0');
define("CONSCENT_CLIENT_ID", get_option('clientId1'));
define("CONSCENT_SDK_URL", get_option('sdkURL'));
define("CONSCENT_API_URL", get_option('CONSCENT_API_URL'));
define("CONSCENT_API_KEY", get_option('CONSCENT_API_KEY'));
define("CONSCENT_API_SECRET", get_option('CONSCENT_API_SECRET'));
define("ANALYTICS_ALL_PAGES_ON", 'Yes');
define("CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT", 2);
define("CONSCENT_DEFAULT_STORY_DURATION", 30);
define("CONSCENT_DEFAULT_STORY_PRICE", 5.00);
define('ROOTDIRdir', plugin_dir_path(__FILE__));
define('FILPBOOK_CATEGORY', 'TFA Magazine - Consent');
register_uninstall_hook(__FILE__, 'conscent_uninstall');
/**
 * conscent_uninstall
 * When user uninstalls the plugin
 * @global type $wpdb
 */
function conscent_uninstall() {
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->prefix}postmeta where meta_key='conscent_price' OR meta_key='conscent_duration'");
}
require_once (ROOTDIRdir . 'Conscent_PostMetaBox.php');
require_once (ROOTDIRdir . 'Conscent_Function.php');
require_once (ROOTDIRdir . 'Conscent_CLass.php');
require_once (ROOTDIRdir . 'js.php');
require_once (ROOTDIRdir . 'Conscent_sections.php');
require_once (ROOTDIRdir . 'Conscent_category.php');
require_once (ROOTDIRdir . 'Conscent_tfa_magazine.php');