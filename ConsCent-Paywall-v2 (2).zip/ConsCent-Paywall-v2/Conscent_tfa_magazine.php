<?php
function conscentTFABookShortcode($atts) {
    //shortcode attributes with default values
    $atts = shortcode_atts(array(
        'category' => FILPBOOK_CATEGORY,
        'limit' => 9,
        'order' => 'DESC',
        'orderby' => 'date',
    ), $atts, 'products');

    $category = $attr['category'];
    $limit = intval($atts['limit']);
    $order = strtoupper($atts['order']);
    $orderby = strtolower($atts['orderby']);
    $allowed_orderby = array('title', 'date');

    // Validate order parameter
    if ($limit < -1 ) {
        return '<p style="color: red;">Error: Invalid `limit` parameter, please user numeric value grater than 0</p>';
    }
    if ($order !== 'ASC' && $order !== 'DESC') {
        return '<p style="color: red;">Error: Invalid `order` parameter, please use "ASC" or "DESC".</p>';
    }
    if (!in_array($orderby, array('date', 'title'))) {
        return '<p style="color: red;">Error: Invalid `orderby` parameter, please Use "date", "title".</p>';
    }

    // Set pased and offset
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $offset = ($paged - 1) * $limit;

    // Query products based on shortcode parameters
    $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'category_name' => 'TFA Magazine - Consent',
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => $orderby,
        'order' => $order,
    );

    $tfa_query = new WP_Query($args);

    if ($tfa_query->have_posts()) {
        // Start output buffer
        ob_start();
        
        echo '<div class="container"><div class="grid-container">';

        while ($tfa_query->have_posts()) {
            $tfa_query->the_post();
            $description = get_post_meta(get_the_ID(), 'description', true);
            $description_limit = 12;
    		$trimmed_description = wp_trim_words($description, $description_limit, '...');

            $featured_image_url = get_the_post_thumbnail_url($post->ID);
            if( empty($featured_image_url) ) continue;
            ?>
                
            <div class="grid-item conscent-grid">
                <?php if( $featured_image_url ) : ?>
                <img src="<?=$featured_image_url?>" width="212px" height="300px"/>
                <?php endif; ?>
                <h3 class="cons-title">#<?php the_title(); ?></h3>
                <a href="<?=the_permalink()?>">READ MORE</a>
            </div>
            <?php
        }

        echo '</div><div class="pagination">';

        // Display pagination links
        echo paginate_links(array(
			'prev_text' => __('<', 'text-domain'),
            'next_text' => __('>', 'text-domain'),
            'total' => $tfa_query->max_num_pages,
        ));

        echo '</div></div>';

        // End output buffer and return content
        return ob_get_clean();
    } else {
        // No products found
        return '<p>No products found.</p>';
    }

    // Restore original post data
    wp_reset_postdata();
}
add_shortcode('tfa_book', 'conscentTFABookShortcode');



function hideMagazineHeaderCSC() {
	$isHeaderHide = false;
	if(is_single()) {
		$categories = get_the_category();
		foreach($categories as $category) {
			if($category->cat_name == FILPBOOK_CATEGORY) {
				$isHeaderHide = true;
				break;
			}
		}
		if($isHeaderHide) {
			echo '<style>
			article.post header.entry-header img{
				display: none;
			}
			</style>';
		}
	}
}

add_filter('wp_footer', 'hideMagazineHeaderCSC');