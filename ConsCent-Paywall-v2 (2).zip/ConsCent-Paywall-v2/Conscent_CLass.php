<?php
// Parent Function that makes the magic happen
function prefix_insert_after_paragraph( $insertion, $paragraph_id, $content ) {
    $closing_p = '</p>';
    $paragraphs = explode( $closing_p, $content );
    foreach ($paragraphs as $index => $paragraph) {
        if ( trim( $paragraph ) ) {
            $paragraphs[$index] .= $closing_p;
        }
        if ( $paragraph_id == $index + 1 ) {
            $paragraphs[$index] .= $insertion;
        }
    }
    return implode( '', $paragraphs );
}

function getPreviewShortCode($shortCode) {
    $isReal3dflipbook = strpos($shortCode, 'real3dflipbook');
    $suffixIndex = strpos($shortCode, ']');
    $extraAttribute = 'mode="lightbox" previewpages="true" hidemenu="true"';
    if ($isReal3dflipbook !== false && $suffixIndex !== false) {
        $newShortCode = substr_replace($shortCode, ' ' . $extraAttribute, $suffixIndex, 0);
        return $newShortCode;
    }else {
        return $shortCode;
    }
}
 
function getShortContent($content) {
    global $wpdb;
    $wpID = get_the_ID();
    $t_ids = get_option('Paywall');
    $cat_meta = get_option("category_$t_ids");
	if(!empty($cat_meta['ContentVisibility'])) {
        $array[]  = $cat_meta['ContentVisibility'];
	}
	$postmeta = $wpdb->base_prefix . 'postmeta';
    $rows_Make = $wpdb->get_results("SELECT * FROM $postmeta where `meta_key`='Conscent_data ' AND `post_id`='$wpID'");
    if (!empty($rows_Make[0]->meta_value)) {
        $VISIBLE = $rows_Make[0]->meta_value;
    } else if (!empty($array)) {
        $VISIBLE = $array[0];
    } else {
        $VISIBLE = CONTENT_VISIBLE_PERCENT_BEFORE_PAYMENT;
    }
	//$VISIBLE;
    $development_code='Coderwolves';
    $dalta = prefix_insert_after_paragraph( $development_code,$VISIBLE, $content );
    $development = explode($development_code,$dalta);
    return $development[0];
}
/**
 * addConscentPayWall
 * Adds the ConsCent Pay Wall
 * @param type $content
 * @return string
 */
function addConscentPayWall($content) {
    global $template; 
    $Chektemp= basename($template);
    if ( is_single() && 'post' == get_post_type() ) {
        $shortCode = getShortContent($content);
        $shortCodeWithPreview = getPreviewShortCode($shortCode);
        $shortContentWithPreview = '<span id="previewPDF">'.$shortCodeWithPreview.'</span>';
        $shortContent = '<span id="originalPDF" style="display:none">'.$content.'</span>';
	    $new_content = '<div id="csc-paywall"></div>';
        $final_content = '<div id="conscent_content">' . $shortContent . $shortContentWithPreview . "...</div>" . $new_content;
        return $final_content;
    } else {
        return $content; 	  
    }
}

/*

 * This function  will be used for validating objec$h
 * we got from storydetails.js file's success call back function.
 * This file will provides output by calling an ajax call to target this function. 
 * @param: consumptionId

 */
function confirmDataFromBackend() {
    $data = $_POST;
    $post_content = get_post_field('post_content', $data['contentId']);
    $consumptionId = $data['consumptionId'];
    $curl = curl_init();
    $checkConsumptionURL = "/content/consumption/$consumptionId";
    $postJsonData['consumptionId'] = $consumptionId;
    $postJsonData = json_encode($postJsonData);
    curl_setopt_array($curl, array(CURLOPT_URL => CONSCENT_API_URL . $checkConsumptionURL, CURLOPT_RETURNTRANSFER => true, CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 0, CURLOPT_FOLLOWLOCATION => true, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => $postJsonData, CURLOPT_HTTPHEADER => array('Accept: application/json', 'Content-Type: application/json', "Authorization: Basic " . base64_encode($apiKeySecret)),));
    $response = curl_exec($curl);
    curl_close($curl);
    $responseArray = json_decode($response);
    if ($responseArray->consumptionId === $consumptionId && $responseArray->payload->contentId === $data['contentId'] && $responseArray->payload->clientId === CONSCENT_CLIENT_ID) {
       echo embedCode($post_content);
        //echo $post_content;
    } else {
        echo "Failed";
    }
    exit();
}
add_action('wp_ajax_nopriv_confirmDataFromBackend', 'confirmDataFromBackend');
add_action('wp_ajax_confirmDataFromBackend', 'confirmDataFromBackend');

add_filter('the_content', 'addConscentPayWall');

function embedCode($post_content) {

	// Regular expression to match URLs
    // $url_pattern = '/(https?:\/\/[^\s]+)/';
	$url_pattern = '/(ht|f)tps?:\/\/[^"]*?(?=<|\s|$)/';

	// Find all URLs in the content
	preg_match_all($url_pattern, $post_content, $matches);

	// Loop through the matched URLs
	foreach ($matches[0] as $url) {
		// Check if the URL is from YouTube, Twitter, Facebook, LinkedIn, Instagram
		
		if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false || strpos($url, 'twitter.com') !== false || strpos($url, 'facebook.com') !== false || strpos($url, 'linkedin.com') !== false || strpos($url, 'instagram.com') !== false || strpos($url, 'xing.com') !== false) {
			$embed_html = wp_oembed_get($url);
            $post_content = str_replace($url, $embed_html, $post_content);
		}
	}
    // Output the modified post content
    return $post_content;
}