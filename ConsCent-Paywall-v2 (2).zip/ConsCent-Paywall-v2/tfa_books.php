<?php
/*
-------------------------------------------------------------------------------------------------
    user [products] shortcode to display products list into page or post
    It accept 3 parameter limit (positive numeric value), order (ASC or DESC) and orderby (date, title, price)
-------------------------------------------------------------------------------------------------
*/
function conscentTFABookShortcode($atts) {
    //shortcode attributes with default values
    $atts = shortcode_atts(array(
        'category' => 'primium',
        'limit' => 3,
        'order' => 'DESC',
        'orderby' => 'date',
    ), $atts, 'products');

    $category = $attr['category'];
    $limit = intval($atts['limit']);
    $order = strtoupper($atts['order']);
    $orderby = strtolower($atts['orderby']);
    $allowed_orderby = array('title', 'date');

    // Validate order parameter
    if ($limit < -1 ) {
        return '<p style="color: red;">Error: Invalid `limit` parameter, please user numeric value grater than 0</p>';
    }
    if ($order !== 'ASC' && $order !== 'DESC') {
        return '<p style="color: red;">Error: Invalid `order` parameter, please use "ASC" or "DESC".</p>';
    }
    if (!in_array($orderby, array('date', 'title'))) {
        return '<p style="color: red;">Error: Invalid `orderby` parameter, please Use "date", "title".</p>';
    }

    // Set pased and offset
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $offset = ($paged - 1) * $limit;

    // Query products based on shortcode parameters
    $args = array(
        'post_type' => 'post',
        'category_name' => 'primium',
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => $orderby,
        'order' => $order,
    );

    $tfa_query = new WP_Query($args);

    if ($tfa_query->have_posts()) {
        // Start output buffer
        ob_start();
        echo '<style>.grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-gap: 20px;
        }

        .grid-item {
            background-color: #f2f2f2;
            padding: 20px;
            text-align: center;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a, span.current {
            display: inline-block;
            padding: 5px 10px;
            margin: 0 5px;
            text-decoration: none;
            border: 1px solid #ccc;
            border-radius: 3px;
            color: #333;
        }

        .pagination .current {
            background-color: #0073e6;
            color: #fff;
        }
        .pagination a:hover {
            background-color: #0073e6;
            color: #fff;
        }
        </style>';
        echo '<div class="container"><h2>Products</h2><div class="grid-container">';

        while ($tfa_query->have_posts()) {
            $tfa_query->the_post();
            $description = get_post_meta(get_the_ID(), 'description', true);
            $description_limit = 12;
    		$trimmed_description = wp_trim_words($description, $description_limit, '...');

            $featured_image_url = get_the_post_thumbnail_url($post->ID);
            if( empty($featured_image_url) ) continue;
            ?>
                
            <div class="grid-item" style="border: 1px solid #696969; margin: 15px;">
                <?php if( $featured_image_url ) : ?>
                <img src="<?=$featured_image_url?>" width="212px" height="300px"/>
                <?php endif; ?>
                <p><strong><?php the_title(); ?>test</strong></p>
                <a href="<?=the_permalink()?>">READ MORE</a>
            </div>
            <?php
        }

        echo '</div><div class="pagination">';

        // Display pagination links
        echo paginate_links(array(
            'total' => $tfa_query->max_num_pages,
        ));

        echo '</div></div>';

        // End output buffer and return content
        return ob_get_clean();
    } else {
        // No products found
        return '<p>No products found.</p>';
    }

    // Restore original post data
    wp_reset_postdata();
}
add_shortcode('tfa_book', 'conscentTFABookShortcode');