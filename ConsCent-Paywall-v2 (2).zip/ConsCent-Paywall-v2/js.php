<?php 

function Conscent_Csc_Paywall_Code() { 
global $post;
if ( is_single() && 'post' == get_post_type() ) {
$author_id     = get_post_field ('post_author', $post->ID);
$display_name  = get_the_author_meta( 'first_name' , $author_id );

foreach(get_the_tags($post->ID) as $tag) {
$tags_list[] = $tag->name;
 }
 
$tags=json_encode($tags_list);
$category_detail=get_the_category($post->ID);//$post->ID
foreach($category_detail as $cd){
$cat_name[] = $cd->cat_name;
}
$cat_name=json_encode($cat_name);
$sections_names = wp_get_object_terms($post->ID,'sections',  array("fields" => "names")); 
$sectionslist=json_encode($sections_names);
?>
<script>
const clientId = '<?php echo CONSCENT_CLIENT_ID;?>';
var sdkURL = '<?php echo CONSCENT_SDK_URL;?>';

(function (w, d, s, o, f, cid) {
    if (!w[o]) {
        w[o] = function () {
            w[o].q.push(arguments);
        };
        w[o].q = [];
    }
    (js = d.createElement(s)), (fjs = d.getElementsByTagName(s)[0]);
    js.id = o;
    js.src = f;
    js.async = 1;
    js.title = cid;
    fjs.parentNode.insertBefore(js, fjs);
})(window, document, 'script', '_csc', sdkURL, clientId);

  const csc = window._csc;
    var contentId = <?php echo $post->ID;?>;
    //var clientSubscriptionUrl = php_vars.client_subscription_url;
   // var conscent_api_url = php_vars.conscent_api_url;

   

console.log("categories", <?php echo $cat_name;?>);

csc('show');
csc('init', {
  debug: true, // can be set to false to remove sdk non-error log output
  contentId: contentId,
  clientId: clientId,
  title:"<?php echo $post->post_title;?>",
  categories: <?php echo $cat_name;?>,
  tags:  <?php echo $tags;?>,
  sections:<?php echo $cat_name;?>,
  authorName: "<?php echo $display_name;?>",
  successCallback: yourSuccessCallbackFunction,
  wrappingElementId: 'csc-paywall',
  fullScreenMode: 'false' // if set to true, the entire screen will be covered,

});



    async function yourSuccessCallbackFunction(validationObject) {
        jQuery('#conscent_content').hide();
		 jQuery.ajax({
            type: "POST",
            dataType: "text",
            url: "/wp-admin/admin-ajax.php",
            data: {consumptionId: validationObject.consumptionId, action: "confirmDataFromBackend", contentId: contentId},
        	success: function (response) {
				if (response.trim() !== "Failed") {
					 //jQuery('#conscent_content').html(response);
				    <?php //if(empty($_GET['Y29uc3VtcHRpb24'])){?>
				  //window.location.href = "?Y29uc3VtcHRpb24=" + response;
				 <?php //} ?>
                  showOriginalPDF();  
                  }else {
					  showPreviewPDF();
				  }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) { 
                console.log("Status: ", textStatus); 
                console.log("Error: ", errorThrown); 
                showPreviewPDF();
            }
        });
    }
</script>
<?php } ?>
<script>
function showOriginalPDF() {
    jQuery('#conscent_content').find('#previewPDF').remove();
    jQuery('#conscent_content').find('#originalPDF').css("display", "block");
    jQuery('#conscent_content').show();
}

function showPreviewPDF() {
    jQuery('#conscent_content').find('#originalPDF').remove();
    jQuery('#conscent_content').find('#previewPDF').css("display", "block");
    jQuery('#conscent_content').show();
}
	
jQuery(document).ready(function() {
	setTimeout(() => {
		if (jQuery("#previewPDF").length) {
			showPreviewPDF();
		}
	}, "5000");
});
</script>
<!-- <style>
	#previewPDF img {
		width: 360px;
	}
</style> -->
<?php } 

add_action('wp_footer','Conscent_Csc_Paywall_Code');
