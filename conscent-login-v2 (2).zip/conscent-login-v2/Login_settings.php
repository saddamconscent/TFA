<?php

function Conscent_settings_page()

{

?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<div class="wrap">
 	
	<div class="container">

	    <h1>Conscent Login </h1>

		<div class="row">

			<div class="col-8 col-md-8">

				<form method="post" action="options.php">

					<?php

						settings_fields("section");

						do_settings_sections("theme-options");      

						submit_button(); 

					?>          

				</form>

			</div>
		</div>

		<div class="col-4 col-md-4">

		Add Login/Logout <b>([ConscentLoginLogout])</b>

		<br>

		Login User Email:-<b>$_COOKIE['username'];</b>

		<br>

		Login User Mobile No:-<b>$_COOKIE['phn'];</b>

		<br>

		Login User Status(True/false):-<b>$_COOKIE['login'];</b>

		<br>

	</div>

</div>

</div>

<?php

}



function Conscent_theme_menu_item() {

add_menu_page("Conscent Login ", "Conscent Login ", "manage_options", "theme-panel", "Conscent_settings_page", null, 99);

}

add_action("admin_menu", "Conscent_theme_menu_item");



function Conscent_clientId1_element() {

?>

  <input type="text"  class="form-control" name="clientId1" id="clientId1" value="<?php echo get_option('clientId1'); ?>" />

    <?php

}



function Conscent_sdk_element() {

	?>

  <input type="text" class="form-control" name="sdkURL" id="sdkURL" value="<?php echo get_option('sdkURL'); ?>" />

  <p><b>https://sandbox-sdk.conscent.in/csc-sdk.js </b>|<b> https://sdk.conscent.in/csc-sdk.js</b></p>

    <?php

}



function Conscent_Paywall_element() {
?>

<select  class="form-control" name="Paywall" id="Paywall">
	<option value="">Select options</option>
		<?php 
      	$categories = get_categories(); 
      	foreach ($categories as $category) {?>
	 		<option value="<?php echo $category->term_id;?>"<?php if($category->term_id==get_option('Paywall')){ ?>selected="selected" <?php } ?>><?php echo $category->cat_name;?>(<?php echo  $category->category_count;?>)</option>
        <?php  }  ?>
  	</select>
<?php

}


function Conscent_API_URL_element() {
?>

  <input type="text" class="form-control" name="CONSCENT_API_URL" id="CONSCENT_API_URL" value="<?php echo get_option('CONSCENT_API_URL'); ?>" />

  <p><b>https://sandbox-api.conscent.in</b> | <b> https://api.conscent.in</b></p>

<?php

}



function Conscent_API_KEY_element() {

?>

  	<input type="text" class="form-control" name="CONSCENT_API_KEY" id="CONSCENT_API_KEY" value="<?php echo get_option('CONSCENT_API_KEY'); ?>" />

    <?php

}



function Conscent_API_SECRET_element() {

?>

  <input type="text" class="form-control" name="CONSCENT_API_SECRET" id="CONSCENT_API_SECRET" value="<?php echo get_option('CONSCENT_API_SECRET'); ?>" />

  <p></p>

<?php

}

function Conscent_AfterLogout_element() {

?>

  	<input type="text" class="form-control" name="AfterLogout" id="AfterLogout" value="<?php echo get_option('AfterLogout'); ?>" />

<?php

}

function Conscent_AfterLoginRedirect_element() {

?>

  	<input type="text"  class="form-control" name="AfterLogin" id="AfterLogin" value="<?php echo get_option('AfterLogin'); ?>" />

    <?php

}



function Conscent_TheamLocation_element() {

?>

	<input type="text"  class="form-control" name="TheamLocation" id="TheamLocation" value="<?php echo get_option('TheamLocation'); ?>" />

<?php

}



function Conscent_DefaultName_element() {

?>

	<select class="form-control" name="DefaultName" id="DefaultName">

		<option value="1" <?php if (get_option('DefaultName') == '1') echo ' selected="selected"'; ?>>Name</option>

		<option value="2" <?php if (get_option('DefaultName') == '2') echo ' selected="selected"'; ?>>Mobile</option>

		<option value="3" <?php if (get_option('DefaultName') == '3') echo ' selected="selected"'; ?>>Email ID</option>

		<option value="4" <?php if (get_option('DefaultName') == '4') echo ' selected="selected"'; ?>>defalt User Name</option>

	</select>

<?php

}

function Conscent_theme_panel_fields() {

	add_settings_section("section", "All Settings", null, "theme-options");

	add_settings_field("clientId1", "Conscent Client Id", "Conscent_clientId1_element", "theme-options", "section");

	add_settings_field("sdkURL", "Conscent sdk URL (Sandbox OR Live)", "Conscent_sdk_element", "theme-options", "section");

	add_settings_field("Paywall", "Paywall Category", "Conscent_Paywall_element", "theme-options", "section");

    add_settings_field("CONSCENT_API_KEY", "Conscent API Key <br>(Sandbox OR Live)", "Conscent_API_KEY_element", "theme-options", "section");

	add_settings_field("CONSCENT_API_SECRET", "Conscent API Secret (Sandbox OR Live)", "Conscent_API_SECRET_element", "theme-options", "section");

	add_settings_field("CONSCENT_API_URL", "Conscent API URL (Sandbox OR Live)", "Conscent_API_URL_element", "theme-options", "section");

	add_settings_field("AfterLogout", "After Logout Redirect)", "Conscent_AfterLogout_element", "theme-options", "section");

	add_settings_field("AfterLogin",  "After Login Redirect)", "Conscent_AfterLoginRedirect_element", "theme-options", "section");

	add_settings_field("TheamLocation","Theme Location Name)", "Conscent_TheamLocation_element", "theme-options", "section");

	add_settings_field("DefaultName","DefaultName)", "Conscent_DefaultName_element", "theme-options", "section");

	add_settings_section("section", "All Settings",null,"theme-options");

	register_setting("section", "Paywall");

	register_setting("section", "clientId1");

	register_setting("section", "sdkURL");

	register_setting("section", "CONSCENT_API_URL");

	register_setting("section", "CONSCENT_API_KEY");

	register_setting("section", "CONSCENT_API_SECRET");

	register_setting("section", "AfterLogout");

	register_setting("section", "AfterLogin");

	register_setting("section", "TheamLocation");

	register_setting("section", "DefaultName");

}

add_action("admin_init", "Conscent_theme_panel_fields");

/*Add Menu Itam*/

add_filter( 'wp_nav_menu_items', 'wti_loginout_menu_link', 10, 2 );

function wti_loginout_menu_link($items,$args ) {

	$TheamLocation=get_option('TheamLocation');

	if ($args->theme_location ==$TheamLocation) {

		if (!empty($_COOKIE['login'])) {

			$items .= '<li> <a href="javascript:void(0)" onclick="javascript:subsLogOut()" target="_parent">Log out</a></li>';

		} else {

			$items .= '<li><a href="javascript:void(0)" onclick="javascript:subsLogin()" target="_parent">Log In</a></li>';

		}

	}

	return $items;

}