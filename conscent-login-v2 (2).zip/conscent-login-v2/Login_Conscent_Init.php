<?php

/*

 * Plugin Name: ConsCent Login V2

 * Description: ConsCent Login for WordPress! 

 * It is not just only plugin but it symbolizes the hope and enthusiasm of an entire media houses to not provide content for free. Content is precious. 

 * Author: ConsCent Developers

 * Author URI: https://conscent.in

 * Version: 2.0

 *  

 */

//menu items

define('LoginRoot', plugin_dir_path(__FILE__));
require_once(LoginRoot . 'Conscent_login_widget.php');
require_once(LoginRoot . 'Conscent_login_Code.php');
require_once(LoginRoot . 'Login_settings.php');