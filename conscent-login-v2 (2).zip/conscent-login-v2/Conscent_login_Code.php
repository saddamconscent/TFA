<?php

function Conscent_login_Code() {

 ?>

  <div id="loginOverlay" style="position: fixed; z-index: 99999; top: 40px; left: 0px; right: 0px; display: block;">

		 <div class="containerfluid">

			<div class="row Custome">

				<div class="colmd12">

					<div id="csc-login"></div>

				</div>

			</div>

		</div>

	</div>

<script language="javascript">

function setCookie(cname,cvalue,exdays){

	var d = new Date();

	d.setTime(d.getTime() + (exdays*60*60*1000));

	var expires = "expires="+ d.toUTCString();	

	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";

}

function getCookie(cname) {

	var name = cname + "=";

	var decodedCookie = decodeURIComponent(document.cookie);

	var ca = decodedCookie.split(';');

	for(var i = 0; i <ca.length; i++) {

		var c = ca[i];

		while (c.charAt(0) == ' ') {

			c = c.substring(1);

		}

		if (c.indexOf(name) == 0) {

			return c.substring(name.length, c.length);

		}

	}

	return "";

}

function deleteCookie(cookieName) {

	document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

}

const subsLogOut = function() {

	const cscLogin = window._csc;

	cscLogin('logout');

	deleteCookie("id");
	deleteCookie("username");
	deleteCookie("phn");
	deleteCookie("name");
	deleteCookie("e_s");
	deleteCookie("login");
	deleteCookie("subscriptions");
	deleteCookie("address");

	// window.location.replace("<?php //echo get_option('AfterLogout'); ?>?Logout=<?php //echo base64_encode(time());?>");
}

const subsLogin = function() {

	document.querySelector("#loginOverlay").style.display = "block";

	const cscLogin = window._csc;

	cscLogin('login-with-redirect');

}

function storeUserDetails() {
	const cscLogin = window._csc;
	cscLogin('get-user-details',{
	successCallbackForUserDetails: async (userDetailsObject) => {

		console.log('Success callback received from conscent login', userDetailsObject);
		window.onbeforeunload = function (userDetailsObject) {
			console.log(userDetailsObject);
			return true;
		}
		setCookie('id',userDetailsObject._id,'365');
		
		setCookie('username',userDetailsObject.email,'365');

		setCookie('phn',userDetailsObject.phoneNumber,'365');

		setCookie('name',userDetailsObject.name,'365');

		setCookie('e_s',userDetailsObject.isSubscriber,'365');

		setCookie('login',userDetailsObject.status,'365');

		var activeSubscriptions = userDetailsObject.activeSubscriptions;
		
		var json_subs = JSON.stringify(activeSubscriptions);

		var address = userDetailsObject.address;
		var json_address = JSON.stringify(address);

		setCookie('address', json_address, '365');
		setCookie('subscriptions', json_subs, '365');
		window.location.reload();
		//window.location.replace("<php echo get_permalink(); ?>?<php echo base64_encode(time());?>=<php echo base64_encode(time());?>/");
	},
	});

}
	
var profileLogoutBtn = document.getElementById("csc-logout");
if(profileLogoutBtn) {
    profileLogoutBtn.addEventListener("click", subsLogOut);
}
</script>

<?php }

add_action('wp_footer','Conscent_login_Code');

function Conscent_login_Check() {
?>
	<style>
		.d-none-mobile {
			display: none;
		}

		.top-bar .ceiling-side {
			display: contents;
		}

		@media (min-width: 45em) {
			.d-none-mobile {
				display: inline;
			}

			.top-bar .ceiling-side {
			display: flex;
		}
		}
	</style>
	<script language="javascript">

		const clientId1 = '<?php echo get_option('clientId1'); ?>';

		(function (w, d, s, o, f, cid) {

			if (!w[o]) {

				w[o] = function () {

				w[o].q.push(arguments);

				};

				w[o].q = [];

			}

			(js = d.createElement(s)), (fjs = d.getElementsByTagName(s)[0]);

			js.id = o;

			js.src = f;

			js.async = 1;

			js.title = cid;

			fjs.parentNode.insertBefore(js, fjs);

		})(window, document, 'script', '_csc', "<?php echo get_option('sdkURL'); ?>", clientId1);

		const cscLogin = window._csc;
		cscLogin('add-auth-state-listener', (userId) => {
			if(userId) {
				// console.log('user is logged in', userId);
				<?php if(empty($_COOKIE['login'])) { ?>
				
					storeUserDetails();

				<?php } ?>
				
			}
		})
	</script>
<?php
}
add_action('wp_head','Conscent_login_Check');

/* create Button*/

function Conscent_login_Link() {
	
	ob_start();

	if (!empty($_COOKIE['login'])) {

	?>

		<?php if($_COOKIE['username']=='undefined') {

			$userNameda= $_COOKIE['phn'];

		} else {

			$userNameda= $_COOKIE['username'];	

		} ?>

			<button style="background-color: #F73D92; color: #fff;  border: none; cursor: pointer;" onclick="toggleDropdown()" class="d-none-mobile">
			<?php echo $userNameda;?>
			</button>

			<button style="background-color: #F73D92; color: #fff;  border: none; cursor: pointer;">
				<a href="<?php echo home_url() . '/user_dashboard'; ?>">My Dashboard</a>
			</button>
	<?php 

	} else {?>
		<button style="background-color: #F73D92; color: #fff;  border: none; cursor: pointer;" onclick="toggleDropdown()">
			<a href="javascript:void(0)" onclick="javascript:subsLogin()" target="_parent">Login</a> 
		</button>

	<?php } 

	return ob_get_clean();
}

add_shortcode("ConscentLoginLogout", "Conscent_login_Link");

function getUserData($params) {
	// Start output buffer
	ob_start();
	
	$key = '';

	if(isset($params) && !empty($params['key'])) {

		$key = $params['key'];
	}

	if(empty($key)) {
		echo "Please enter correct key";
		// exit;
	}

	if($key == 'name') {
		if(empty($_COOKIE['name']) || $_COOKIE['name'] == 'undefined') {
			echo "--";
		}else {
			echo $_COOKIE['name'];
		}
	}else if($key == 'email') {
		if(empty($_COOKIE['username']) || $_COOKIE['username'] == 'undefined') {
			echo "--";
		}else {
			echo $_COOKIE['username'];
		}
	}else if($key == 'phone') {
		if(empty($_COOKIE['phn']) || $_COOKIE['phn'] == 'undefined') {
			echo "--";
		}else {
			echo $_COOKIE['phn'];
		}
	}else if($key == 'subscriptions') {
		// subscriptionInfo_shortcode();
		if(empty($_COOKIE['subscriptions']) || $_COOKIE['subscriptions'] == 'undefined' || $_COOKIE['subscriptions'] == '[]') {
			echo "--";
		}else {
			$subs_str = "";
			$subs_arr = array();
			$all_subscriptions = json_decode(str_replace('\\', '', $_COOKIE['subscriptions']));
			foreach($all_subscriptions as $subscription) {
				$subs_str = "";
				$expiry_date = date_create($subscription->expiryDate);
				$formatted_expiry_date = date_format($expiry_date, "M d Y H:i:s");
				$subs_str .= "<p><strong>Subsription Plan: </strong>" . $subscription->subscriptionDetails->duration . " Month ";
				$subs_str .= "<strong> Expiry Date: </strong>" . $formatted_expiry_date . "<p>";
				$subs_arr[] = $subs_str;
			}
			$subs_str = implode("<hr><br>", $subs_arr);
			echo $subs_str;
		}
		
	}

	// End output buffer and return content
	return ob_get_clean();
}
add_shortcode('userDetails', 'getUserData');


function subscriptionInfo_shortcode() {
	echo '<span id="subscription-wrapper"> </span>';
?>
	<script>

		cscLogin('get-user-details',{
		successCallbackForUserDetails: async (userDetailsObject) => {
			console.log("User Details Objects: ", userDetailsObject);
			
			window.onbeforeunload = function (userDetailsObject) {
				console.log(userDetailsObject);
				return true;
			}

			var activeSubscriptions = userDetailsObject.activeSubscriptions
			var subscriptionString = '';
			var subscriptions = [];
			activeSubscriptions.forEach(function(obj) {
				if(obj.type == 'SUBSCRIPTION') {
					let duration = obj.subscriptionDetails.duration;
					subscriptionString = "<p><strong>Subsription Plan: </strong>" + duration + " Month ";
					subscriptionString += "<strong> Expiry Date: </strong>" + obj.expiryDate + "<p>";
					subscriptions.push(subscriptionString);
				}
			});
			subscriptionString = subscriptions.join('<hr>');
			$('#subscription-wrapper').append(subscriptionString);

			},
		});

	</script>
<?php	
}