<?php // Silence is golden.

