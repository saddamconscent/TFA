<?php

ob_start();

 class Conscent_Login_Registration extends WP_Widget {

	static private $login_registration_status123;

    /**

	 * Register widget with WordPress.

	 */

	function __construct() {

		parent::__construct(

			'Conscent_Login_Registration', // Base ID

			__( 'Conscent Login', 'Conscent' ), // Name

			array( 'description' => __( 'Conscent Login', 'Conscent' ), ) // Args

		);

	}

    public function widget( $args, $instance ) { ?>

		<?php

		$title = apply_filters( 'widget_title', $instance['title'] );

		echo $args['before_widget'];

		if ( ! empty( $title ) ) {

			echo $args['before_title'] . $title . $args['after_title'];

		}

		?>

		<div class="login-reg-error"><?php echo self::$login_registration_status123; ?></div>

   		<div id="flip-tabs">

  		<?php  

		if (!empty($_COOKIE['login'])) {

		?>

			<h2 class="widget-title">Welcome <?php if($_COOKIE['username']=='undefined') {

				$userNameda= $_COOKIE['phn'];

			}else{

				$userNameda= $_COOKIE['username'];	

			}
			echo $userNameda;?>!</h2> 

           	<a href="javascript:void(0)" onclick="javascript:subsLogOut()" target="_parent">Logout</a> 

              

		 	<?php 

		} else { ?>

			 <li class="signin"><a href="javascript:void(0)" onclick="javascript:subsLogin()" target="_parent">Login</a></li> 

        <?php } ?>

        </div>

		<?php

		echo $args['after_widget'];

	}

	public function form( $instance ) {

		if ( isset( $instance['title'] ) ) {

			$title = $instance['title'];

		} else {

			$title = __( 'Login / Welcome', 'text_domain' );

		}

		?>

		<p>

  		<label for="<?php echo $this->get_field_id( 'title' ); ?>">

    		<?php _e( 'Title:' ); ?>

  		</label>

  		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		
		</p>

	<?php

	}

	public function update( $new_instance, $old_instance ) {

		$instance = array();

		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $instance;

	}



} // class Conscent_Login_Registration



// register Foo_Widget widget

function register_Conscent_Login_Registration() {

	register_widget( 'Conscent_Login_Registration' );

}

add_action( 'widgets_init', 'register_Conscent_Login_Registration' );